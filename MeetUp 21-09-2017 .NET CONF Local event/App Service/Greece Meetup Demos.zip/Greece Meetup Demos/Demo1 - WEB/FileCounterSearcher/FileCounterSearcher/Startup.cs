﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(FileCounterSearcher.Startup))]
namespace FileCounterSearcher
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {

        }
    }
}
