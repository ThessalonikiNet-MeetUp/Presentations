﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using FileCounterSearcher.Models;
using PagedList;
using static System.String;
using System;

namespace FileCounterSearcher.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(int? page, string query = "")
        {
            int pageNumer = page ?? 1;

            //get data
            var list = GetFileInformation();

            if (!IsNullOrEmpty(query))
                list = new List<SiteFileViewModel>(list.Where(d => d.Files.Any(e => e.Name.Contains(query))));

            var data = list.ToPagedList(pageNumer, 5);

            ViewBag.Query = query;

            return View(data);
        }

        private List<SiteFileViewModel> GetFileInformation()
        {
            string folder = Environment.ExpandEnvironmentVariables(@"%HOME%\site\wwwroot");
            
            var dir = new DirectoryInfo(folder);

            // This method assumes that the application has discovery permissions
            // for all folders under the specified path.
            var fileList = dir.GetFiles("*.*", SearchOption.AllDirectories);

            // Create the query.
            var queryGroupByExt =
                from file in fileList
                group file by file.Extension.ToLower() into fileGroup
                let fileCount = fileGroup.Count()
                orderby fileCount descending, fileGroup.Key ascending
                select fileGroup;

            var list = new List<SiteFileViewModel>();

            foreach (var current in queryGroupByExt)
            {
                list.Add(new SiteFileViewModel
                {
                    Extension = current.Key,
                    FileCount = current.Count(),
                    Files = current.ToList()
                });
            }

            return list;
        }

    }
}