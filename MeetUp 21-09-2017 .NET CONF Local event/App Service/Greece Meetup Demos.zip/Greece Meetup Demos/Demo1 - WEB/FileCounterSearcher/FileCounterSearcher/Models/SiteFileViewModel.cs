﻿using System.Collections.Generic;
using System.IO;

namespace FileCounterSearcher.Models
{
    /// <summary>
    /// Class SiteFileViewModel.
    /// </summary>
    public class SiteFileViewModel
    {
        /// <summary>
        /// Gets or sets the extension.
        /// </summary>
        /// <value>The extension.</value>
        public string Extension { get; set; }
        /// <summary>
        /// Gets or sets the file count.
        /// </summary>
        /// <value>The file count.</value>
        public int FileCount { get; set; }
        /// <summary>
        /// Gets or sets the files.
        /// </summary>
        /// <value>The files.</value>
        public List<FileInfo> Files { get; set; }
    }
}