﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using CoreFtp;
using Microsoft.Azure.Management.AppService.Fluent;
using Microsoft.Azure.Management.Fluent;
using Microsoft.Azure.Management.ResourceManager.Fluent;
using Microsoft.Azure.Management.ResourceManager.Fluent.Core;

namespace MamlTest
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        async void ButtonBase_OnClick(object sender, RoutedEventArgs e)
        {
            //authenticate with azure
            string path = @"C:\Users\bojan\Desktop\Greece Meetup Demos\Demo1 - WEB\my.azureauth.txt";
            var credentials = SdkContext.AzureCredentialsFactory.FromFile(path);
            var azure = Azure
                .Configure()
                .WithLogLevel(HttpLoggingDelegatingHandler.Level.Basic)
                .Authenticate(credentials)
                .WithDefaultSubscription();
            //create web app
            var greecedemoplan = "/subscriptions/0c8a0702-6312-4677-9c40-bdb61307352f/resourceGroups/GreeceResourceGroup/providers/Microsoft.Web/serverfarms/GreeceDemoPlan";
            var webApp = azure.WebApps.Define("greecedemoapp2")
                              .WithExistingWindowsPlan(azure.AppServices.AppServicePlans.GetById(greecedemoplan))
                              .WithExistingResourceGroup("GreeceResourceGroup")
                              .Create();
            //upload HTML file
            var publishingProfile = webApp.GetPublishingProfile();
            await UploadFileToWebApp(publishingProfile,
                @"C:\Users\bojan\Desktop\Greece Meetup Demos\Demo1 - WEB\Index.html");

            //get prod url and open browser
            Process.Start($"http://{webApp.Name}.azurewebsites.net");
        }

        public static async Task UploadFileToWebApp(IPublishingProfile profile,
            string filePath)
        {
            string host = profile.FtpUrl.Split(new[] { '/' }, 2)[0];

            using (var ftpClient = new FtpClient(new FtpClientConfiguration
            {
                Host = host,
                Username = profile.FtpUsername,
                Password = profile.FtpPassword
            }))
            {
                var fileinfo = new FileInfo(filePath);
                await ftpClient.LoginAsync();
                if ((await ftpClient.ListDirectoriesAsync()).All(fni => fni.Name != "site"))
                {
                    await ftpClient.CreateDirectoryAsync("site");
                }
                await ftpClient.ChangeWorkingDirectoryAsync("./site");
                if ((await ftpClient.ListDirectoriesAsync()).All(fni => fni.Name != "wwwroot"))
                {
                    await ftpClient.CreateDirectoryAsync("wwwroot");
                }
                await ftpClient.ChangeWorkingDirectoryAsync("./wwwroot");
                string fileName = Path.GetFileName(filePath);
                using (var writeStream = await ftpClient.OpenFileWriteStreamAsync(fileName))
                {
                    var fileReadStream = fileinfo.OpenRead();
                    await fileReadStream.CopyToAsync(writeStream);
                }
            }
        }
    }
}
