﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Mail;
using System.Net.Mime;
using System.Web.Http;
using Swashbuckle.Swagger.Annotations;

namespace MyAPI.Controllers
{
    public class ValuesController : ApiController
    {
        // GET api/values
        [SwaggerOperation("GetAll")]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        [SwaggerOperation("GetById")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.NotFound)]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/values
        [SwaggerOperation("SendEmail")]
        [SwaggerResponse(HttpStatusCode.Created)]
        public void Post([FromUri]string value)
        {
            var username = "[username for SendGrid]";
            var password = "[Password]";
            var smtpServer = "smtp.sendgrid.net";

            var mailMsg = new MailMessage();

            // To
            mailMsg.To.Add(new MailAddress("[TO EMAIL]", "Bojan"));

            // From
            mailMsg.From = new MailAddress("info@greecedemo.com", "Demo");

            // Subject and multipart/alternative Body
            mailMsg.Subject = "Sending email from API";
            string text = $"This is a message on {DateTime.Now} with message {value}";
            string html = $"<p>{text}</p>";
            mailMsg.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(text, null,
                MediaTypeNames.Text.Plain));
            mailMsg.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(html, null,
                MediaTypeNames.Text.Html));

            // Init SmtpClient and send
            var smtpClient = new SmtpClient(smtpServer,
                                            Convert.ToInt32(587))
            {
                Credentials = new NetworkCredential(username, password)
            };
            smtpClient.Send(mailMsg);
        }

        // PUT api/values/5
        [SwaggerOperation("Update")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.NotFound)]
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        [SwaggerOperation("Delete")]
        [SwaggerResponse(HttpStatusCode.OK)]
        [SwaggerResponse(HttpStatusCode.NotFound)]
        public void Delete(int id)
        {
        }
    }
}
