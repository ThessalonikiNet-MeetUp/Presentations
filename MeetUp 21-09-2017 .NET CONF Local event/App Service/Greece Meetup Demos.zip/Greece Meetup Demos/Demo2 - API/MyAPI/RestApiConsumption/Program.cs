﻿using System;
using Greece;
using Microsoft.Rest;

namespace RestApiConsumption
{
    class Program
    {
        static void Main(string[] args)
        {
            var client2 = new GreeceDemoAPI1(new Uri("http://greecedemoapi1.azurewebsites.net",
                    UriKind.RelativeOrAbsolute),
                new TokenCredentials("this is secure :)"));
            client2.SendEmailWithHttpMessagesAsync("Hello").GetAwaiter().GetResult();
            //var client = new RestApiConsumptionClient(
            //    new Uri("http://greecedemoapi1.azurewebsites.net",
            //    UriKind.RelativeOrAbsolute),
            //    new TokenCredentials("this is secure :)"));

            //var response = client.GetAllWithHttpMessagesAsync().GetAwaiter().GetResult();
            //foreach (var current in response.Body)
            //{
            //    Console.WriteLine(current);
            //}
            Console.Read();
        }
    }
}
