﻿using System;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using GreeceDemo1.Models;
using Microsoft.WindowsAzure.MobileServices;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace GreeceDemo1
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void ButtonBase_OnClick(object sender, RoutedEventArgs e)
        {
            var table = App.GreeceMobileAppClient.GetTable<Message>();
            await table.InsertAsync(new Message
            {
                Id = Guid.NewGuid().ToString(),
                Text = "Hello from client " + DateTime.Now
            });
        }

        private async void GetItems_Click(object sender, RoutedEventArgs e)
        {
            var table = App.GreeceMobileAppClient.GetTable<Message>();
            var query = table.CreateQuery().OrderBy(d => d.Id);
            var messages = await query.ToListAsync();
            lbData.ItemsSource = messages;
        }
    }
}
