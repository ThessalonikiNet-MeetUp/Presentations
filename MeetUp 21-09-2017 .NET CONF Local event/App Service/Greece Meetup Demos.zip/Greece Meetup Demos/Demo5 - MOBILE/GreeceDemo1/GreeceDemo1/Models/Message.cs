﻿using Newtonsoft.Json;

namespace GreeceDemo1.Models
{
    public class Message
    {
        public string Id { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Text { get; set; }
    }
}